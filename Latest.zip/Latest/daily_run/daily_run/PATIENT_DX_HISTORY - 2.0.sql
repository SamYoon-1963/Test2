
--region create temp tables with member dates (member roster dates & pdm dates created)
--get min member_date
DROP TABLE IF EXISTS member_dates_min;
CREATE LOCAL TEMP TABLE member_dates_min
ON COMMIT PRESERVE ROWS AS

--get all distinct members by client 
SELECT 
  DATA_SOURCE,
  CLIENT,
  MEMBER_ID
  --create an 'enroll start date' by using the first stay admit date
  ,MIN(STAY_ADMIT_DATE) AS FIRST_ADMIT_DATE 
FROM MEDECON_PRD.PDM a
--only have in contract data
WHERE LEFT(a.CONTRACT_PERIOD,2)='CY'
GROUP BY 1,2,3--,4
;


--SELECT COUNT(*) FROM member_dates_all;
--end region

--region create table with important dates for each member
DROP TABLE IF EXISTS member_dx;
CREATE LOCAL TEMP TABLE member_dx
ON COMMIT PRESERVE ROWS AS

SELECT
  m.DATA_SOURCE,
  m.CLIENT,
  m.MEMBER_ID,
  b.FIRST_ADMIT_DATE,
  m.STAY_ADMIT_DATE,
  m.DX1
  ,m.DX2
  ,m.DX3
FROM MEDECON_PRD.PDM AS m 
LEFT JOIN member_dates_min b
USING(DATA_SOURCE,CLIENT, MEMBER_ID)
WHERE LEFT(m.CONTRACT_PERIOD,2)='CY' 
--GROUP BY 1,2,3,4,5
  ;
  
--SELECT * FROM member_dx
--WHERE CLIENT = 'AMBETTER' AND MEMBER_ID='U9517014101'--'U9583038402'
--ORDER BY DATA_SOURCE,STAY_ADMIT_DATE
--;
--end region




--region create temp tables for each dx code
DROP TABLE IF EXISTS dx1_all;
CREATE LOCAL TEMP TABLE dx1_all
ON COMMIT PRESERVE ROWS AS

--all dx1 list for each member_id by time
SELECT 
  DATA_SOURCE, CLIENT, MEMBER_ID, FIRST_ADMIT_DATE, STAY_ADMIT_DATE,
  LISTAGG(DISTINCT DX1) as all_DX1 
FROM member_dx
GROUP BY 1,2,3,4,5
ORDER BY MEMBER_ID, FIRST_ADMIT_DATE;

--all dx2 list for each member_id by time
DROP TABLE IF EXISTS dx2_all;
CREATE LOCAL TEMP TABLE dx2_all
ON COMMIT PRESERVE ROWS AS
SELECT 
  DATA_SOURCE, CLIENT, MEMBER_ID, FIRST_ADMIT_DATE, STAY_ADMIT_DATE,
  LISTAGG(DISTINCT DX2) as all_DX2
FROM member_dx
GROUP BY 1,2,3,4,5
ORDER BY MEMBER_ID, FIRST_ADMIT_DATE;

--all dx3 list for each member_id by time
DROP TABLE IF EXISTS dx3_all;
CREATE LOCAL TEMP TABLE dx3_all
ON COMMIT PRESERVE ROWS AS
SELECT 
  DATA_SOURCE, CLIENT, MEMBER_ID, FIRST_ADMIT_DATE, STAY_ADMIT_DATE,
  LISTAGG(DISTINCT DX3) as all_DX3
FROM member_dx
GROUP BY 1,2,3,4,5
ORDER BY MEMBER_ID, FIRST_ADMIT_DATE;
--end region

--region create static table in vertica
DROP TABLE IF EXISTS DATALAB_WORK_PRD.PATIENT_DX_HISTORY_DEV;
CREATE TABLE DATALAB_WORK_PRD.PATIENT_DX_HISTORY_DEV AS 

SELECT *, COALESCE(all_DX1,'') ||','||COALESCE(all_DX2,'') ||','||COALESCE(all_DX3 ,'') AS all_DXs
FROM dx1_all
LEFT JOIN dx2_all
USING(DATA_SOURCE, CLIENT, MEMBER_ID, FIRST_ADMIT_DATE, STAY_ADMIT_DATE)
LEFT JOIN dx3_all
USING(DATA_SOURCE, CLIENT, MEMBER_ID, FIRST_ADMIT_DATE, STAY_ADMIT_DATE)
;
--end region


--SELECT * FROM DATALAB_WORK_PRD.PATIENT_DX_HISTORY_DEV
--WHERE CLIENT = 'AMBETTER' AND MEMBER_ID='U9517014101'--'U9583038402'
--ORDER BY DATA_SOURCE,STAY_ADMIT_DATE
--;