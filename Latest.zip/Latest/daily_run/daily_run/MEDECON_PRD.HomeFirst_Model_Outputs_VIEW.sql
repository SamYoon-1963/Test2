--region create view that just has the most up to date scores for each patient (NOT NEEDED FOR PROD since already made)
--QUESTION: NEED TO CHECK THIS IS THE CORRECT WA?LY?
DROP VIEW IF EXISTS MEDECON_PRD.HomeFirst_Model_Outputs_VIEW;
CREATE VIEW MEDECON_PRD.HomeFirst_Model_Outputs_VIEW AS 
SELECT *
FROM MEDECON_PRD.HomeFirst_Model_Outputs
--WHERE DATEOFPREDICTIONS IS NOT NULL
LIMIT 1 OVER(PARTITION BY DATA_SOURCE, CLIENT, MEMBER_ID, STAY_ADMIT_DATE 
ORDER BY DateOfPredictions DESC)
;
--end region