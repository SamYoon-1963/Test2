--RUN THIS QUERY EVERYDAY
--AND THEN AFTER THIS RUN HAVE MEDECON_PRD.HomeFirst_Model_Outputs_VIEW integrated into daily ops run


--2. then inserts into the history table
INSERT INTO MEDECON_PRD.HomeFirst_Model_Outputs
SELECT 
DATA_SOURCE, CLIENT, MEMBER_ID, EPI_ID, PAID_THRU_DATE, STAY_ADMIT_DATE, 
Readmission_Likelihood, SNF_Discharge_Likelihood, pred_Home_RA, pred_SNF_RA, ChangeIfHome, zscore, Recommendation, DateOfPredictions::TIMESTAMP

FROM
--1. takes all patients who are in the hospital (aka whose stay_discharg_date is null) and makes homefirst model predictions
DATALAB_PRD.HomeFirst_Model_Outputs_DEV;

--3. MEDECON_PRD.HomeFirst_Model_Outputs_VIEW is a view that only has the most recent prediction info for each member, epi_id, data_source & client (drawn from MEDECON_PRD.HomeFirst_Model_Outputs
;
