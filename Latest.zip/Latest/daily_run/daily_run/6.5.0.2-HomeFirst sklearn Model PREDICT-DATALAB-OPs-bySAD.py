#!/usr/bin/env python
# coding: utf-8

# # Home First Model Predictions

# Changes in this NB:
# - this notebook utilized the saved max home cih score from the trained models in lieu of creating a new zscore (so that it doesn't reset for each sample of data)
# 
# This notebook is to load the models trained in 6.3.2 NB and make historical predictions to MEDECON_PRD.HomeFirst_Model_Outputs
# 
# This sklearn model was created when it was realized the verticapy POC models for those who followed the verticapy POC SNF recommendations were readmitting at higher rates than those who did not.
# 
# 

# # Imports

# In[1]:


#Importing libraries, loading the data

import timeit
#start = timeit.default_timer()
import pickle
import pandas as pd
import statsmodels.formula.api as sm
from datetime import date
import numpy as np
import math
import random
from sklearn import metrics
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LogisticRegression
from sklearn.linear_model import LinearRegression
from sklearn.datasets import make_regression
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import sklearn.datasets
from sklearn.dummy import DummyClassifier
import pandas
import numpy as np
import pdb
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.decomposition import PCA
import pickle

from datetime import datetime

#import treeinterpreter as ti

#set matplot lib style to 538
plt.style.use('fivethirtyeight')

#pd.set_option('display.max_columns', None)
#pd.set_option('display.max_rows', 500)

#pandas profiling
#from pandas_profiling import ProfileReport


# In[2]:


#comment to hide graphics
#%matplotlib inline


# In[3]:


#Vertica Library
import vertica_python
from verticapy.utilities import *


# In[4]:



# Compare Algorithms
from sklearn import model_selection
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC


# In[5]:


from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.naive_bayes import GaussianNB
#from xgboost import XGBClassifier
from sklearn import model_selection
from sklearn.utils import class_weight
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix
import time
# creating zscores
import scipy.stats as stats


# In[6]:


#get time of beginning of code
startCodeTime = time.time()


# # User Defined Functions

# In[7]:


#define functions to explore a pandas dataframe 
def data_explore_func(dataframe):
    '''explore dataframe columns, dtypes, info, unique values, min, max, mean, and check for NaNs/duplicates'''
    print('List of Dataframe Columns\n\n',dataframe.columns)
    #print('\n\nData Types in this Dataframe\n\n',dataframe.dtypes)
    print('\n\nInfo of this Dataframe\n')
    print(dataframe.info())
    print('\n\nUnique Values (by column) in this Dataframe\n\n',dataframe.nunique().sort_values(ascending=False))
    print('\n\nUnique Values (by column) as % in this Dataframe\n\n',(dataframe.nunique()/len(dataframe)*100).sort_values(ascending=False))
    print('\n\nUnique Values for Every Column as (%)\n')
    for col in dataframe.columns:
        print(col)
        print(dataframe[col].value_counts()/len(dataframe[col])*100)
        print('\n')
    print('\n\nSummary Statistics of this Dataframe\n\n',dataframe.describe(include='all'))
    print('\n\nNull Values by Column as (%)')
    print((dataframe.isna().sum()/len(dataframe)*100).sort_values(ascending=False))
    print('\n\nDuplicates in this Dataframe\n',len(dataframe[dataframe.duplicated()]))
    print('Duplicates as a % of total Dataframe\n',len(dataframe[dataframe.duplicated()])/len(dataframe)*100)


# # Data Initialization

# ### Vertica Connection

# In[8]:


#Read in values
#with open(r'C:\Users\JJFRASC\Documents\CCx Projects\Vertica_Extractions\vertica1.txt') as f:
#version on VM
with open(r'C:\Users\Product_Reporting_Sv\Desktop\Python Projects\JJFRASC\Vertica_Extractions\vertica1.txt') as f:
    vertica1 = f.read()
    f.close()
    
#with open(r'C:\Users\JJFRASC\Documents\CCx Projects\Vertica_Extractions\vertica2.txt') as f:
#version on VM
with open(r'C:\Users\Product_Reporting_Sv\Desktop\Python Projects\JJFRASC\Vertica_Extractions\vertica2.txt') as f:
    vertica2 = f.read()
    f.close()

# Build vertica connection
vert_str = {
            'host': 'P1VERTICA', #production environment
            #'host': 'D1VERTICA', #developer environment
            'port': 5433,
            'user': vertica1, #enter your username
            'password': vertica2,  #enter your password
            'database': 'P1DA01', #production environment
            #'database': 'D1DA01', #developer environment
            'read_timeout': 600,
            'unicode_error': 'strict',
            'ssl': True
            }


# # NEED TO LIMIT YEAR AND CLIENT?
# YEAR & count 
# - 2019	38933
# - 2020	129875
# - 2021	182618
# - 2022	306096
# - 2023	87221
# 
# Plan:
# - 2019 + 2020
# - 2021
# - 2022 1/2 way
# - 2022 2/2 way
# - 2023 in final table?

# # NOTE NEED TO REMOVE WHERE STAY_DISCHARGE_DATE IS NULL OR AFTER FIRST RUN OF OPS

# In[9]:


#limit to clients of interest and patients currently in HOS or don't have epi_homefirst_recc 
data_sql = '''
SELECT * FROM DATALAB_PRD.HomeFirst_Model_Inputs_DEV
WHERE CLIENT IN ('WELLCARE', 'FL BLUE', 'HORIZON', 'OPTIMA', 'AMBETTER') 
AND (STAY_DISCHARGE_DATE IS NULL OR EPI_HOS_HOMEFIRST_RECOMMENDATION IS NULL)
;
'''


# In[10]:


#%%time
#Vertica connection to extract data from Vertica table
with vertica_python.connect(**vert_str) as connection:
    #create connection
    cur = connection.cursor('dict')
    
    #get input data for models
    cur.execute(data_sql)
    claims_data = pd.DataFrame(cur.fetchall())


# # Explore Input Data - EDA

# ### Claims Data

# #### (operations data but labeled as claims for lazy code updates)

# In[11]:


#data_explore_func(claims_data)


# In[12]:


claims_data.CLIENT.value_counts()


# In[13]:


claims_data.dtypes


# In[14]:


#get all object columns
cols_to_float = claims_data.columns[claims_data.dtypes.eq('object')].values


# In[15]:


#define columns that are truly string objects
true_objects = [ 'MEMBER_ID', 'EPI_ID', 'PAID_THRU_DATE',
       'STAY_ADMIT_DATE', 'STAY_DISCHARGE_DATE', 'Discharge_To', 'CLIENT',
       'DATA_SOURCE', 'EPI_HOS_HOMEFIRST_RECOMMENDATION']
#remove the true objects from the columns to convert to numeric
cols_to_float  = [e for e in cols_to_float if e not in true_objects]


# In[ ]:


#%%time
#convert these colums to floats
claims_data[cols_to_float] = claims_data[cols_to_float].apply(pd.to_numeric)#, errors='coerce')


# In[ ]:


#check if there are any that need to be deleted
claims_data.select_dtypes(include='object').columns.values


# In[ ]:


claims_data.describe()


# In[ ]:


len(claims_data)


# In[ ]:


#get how many columns there are
len(claims_data.columns)


# In[ ]:


#see columns that are all null
claims_data.columns[claims_data.isna().all()].tolist()


# In[ ]:


#DROP ANY COLUMNS THAT ARE ALL NULL
claims_data.dropna(axis=1, how='all', inplace=True)
#see how many columns we have now
len(claims_data.columns)


# In[ ]:


#see columns that are all null
claims_data.columns[claims_data.isna().any()].tolist()


# In[ ]:


#look at when member age is less than 0
#consider recalculating it with member dob and current date?
print('there are', len(claims_data[claims_data.MEMBER_AGE<0]), 'rows that have member_age <0')


# # Data manipulation

# In[ ]:


#create column that is binary 1 if discharged home, 0 if not
#claims_data['Discharge_Home'] = np.where(claims_data.Discharge_To=='Home Without Care', 1, 
 #        np.where(claims_data.Discharge_To=='Home With Care', 1,0))


# In[ ]:


#check to see if succesfull
#claims_data.groupby(['Discharge_To', 'Discharge_Home']).count()['Readmit_90']


# # Model Pipelines    
# 

# In[ ]:


#load models

#prod version
with open(r'\\ccx.carecentrix.com\shares\CCX\HomeFirst\Discharge Options\Prod\1_Automated_Process\Data\Model\DEV_OPS_HomeFirst_model_dictionary2023-06-29.pkl', 'rb') as file:
#with open(r'C:\Users\JJFRASC\Documents\CCx Projects\Advanced Data Labs Projects\POC-RiskStrat-SNFLikely_toVertica\models\DEV_OPS_HomeFirst_model_dictionary2023-06-29.pkl', 'rb') as file:    
    
    models = pickle.load(file) 
    #get the four models and the X columns needed to predict the target variable
    Home_pianobar = models['Home']
    Home_cols = models['Home_cols']
    SNF_pianobar = models['SNF']
    SNF_cols = models['SNF_cols']
    Readmission = models['RA_model']
    RA_model_cols = models['RA_model_cols']
    SNF_Likely = models['Discharge_model']
    SNF_Likely_model_cols = models['Discharge_model_cols']
    cihFor_zscore = 0.15#0.2465 # #models['cihFor_zscore']
    #get the pca/scaler and other datas
    #pca = models['pca_demographics']
    #Scaler = models['Scaler']
    #icd10 = models['dxs']
    #risks = models['dx_risks']
    #svi = models['svi_map']


# In[ ]:


cihFor_zscore


# ## Create Recommendations

# In[ ]:


#%%time
print('making predictions...') #print for visual control
#make predictions from loaded models
claims_data['SNF_Discharge_Likelihood'] = SNF_Likely.predict_proba(claims_data[SNF_Likely_model_cols])[:,1]
claims_data['Readmission_Likelihood'] = Readmission.predict_proba(claims_data[RA_model_cols])[:,1]
claims_data['pred_Home_RA'] = Home_pianobar.predict_proba(claims_data[Home_cols])[:,1]
claims_data['pred_SNF_RA'] = SNF_pianobar.predict_proba(claims_data[SNF_cols])[:,1]



print('generating recommendations...')#print for visual control
#create change if home column
claims_data['ChangeIfHome'] =  claims_data['pred_Home_RA'] - claims_data['pred_SNF_RA']

#create zscore based on CIH variable
#putting in null b/c using traing data - max cih from home recc as zscore 
claims_data['zscore'] = np.nan#stats.zscore(claims_data['ChangeIfHome'])
#use max cih from home recc in place of zscore
#otherwise this recommendation will reset based on only that runs' sample
claims_data['Recommendation'] = np.where(claims_data.sickle==1,'Path of Care Override - Sickle Cell',
                                             np.where(claims_data.ChangeIfHome>cihFor_zscore, 'SNF', 'Home'))


#create column, if zscore above 90% threshold, send SNF else home
#claims_data['Recommendation'] = np.where(claims_data.zscore>1.645, 'SNF', 'Home')
#except when sickle cell
#claims_data['Recommendation'] = np.where(claims_data.sickle==1,'Path of Care Override - Sickle Cell',
 #                                            np.where(claims_data.zscore>1.96, 'SNF', 'Home'))


#create numerical column for Recommendation
#claims_data['RecommendationBinary'] = np.where(claims_data['Recommendation']=='Home', 1,0)



# In[ ]:


claims_data.describe()['ChangeIfHome']


# In[ ]:


# datetime object containing current date and time
from datetime import datetime
#now = datetime.now()
now = pd.to_datetime('today')
 
# dd/mm/YY H:M:S
#dt_string = now.strftime("%Y/%m/%d %H:%M:%S")

#write in the today's date as the date of prediction
#so this can be catalogued and tracked
#with time as well if there are more recent runs in one day
claims_data['DateOfPredictions'] = now


# ## Save Data to Vertica

# In[ ]:


#filter data to columns needed for push to vertica
claims_data_toDB = claims_data[['DATA_SOURCE', 'CLIENT', 'MEMBER_ID', 'EPI_ID',  'PAID_THRU_DATE', 'STAY_ADMIT_DATE',  
                       "Readmission_Likelihood", "SNF_Discharge_Likelihood", "pred_Home_RA", "pred_SNF_RA",
                       'ChangeIfHome','zscore','Recommendation','DateOfPredictions']]


# In[ ]:


#see prediction summary stats
claims_data_toDB.describe()


# In[ ]:


#set schema name in vertica
schema = 'DATALAB_PRD'

#set table name in vertica
table = 'HomeFirst_Model_Outputs_DEV'


# In[ ]:


#%%time
#Vertica connection to extract data from Vertica table
with vertica_python.connect(**vert_str) as connection:
    #create connection
    cur = connection.cursor()
    
    #delete old records from table
    del_sql = 'drop table '+schema +'.' + table
    cur.execute(del_sql)
    print('Dropped ' +table)


# In[ ]:


with vertica_python.connect(**vert_str) as connection:
#create connection
    cur = connection.cursor()

    start = time.time()
    #save pandas dataframe as vertica temp table
    pandas_to_vertica(df = claims_data_toDB,
                      cursor = cur,
                      name = table,
                      schema = schema
                     )

    #push vertica temp table to static table in vertica
    #temp.to_db(name=schema+'.'+table, relation_type="table")
    elapsed = round((time.time()-start)/60,2)
    print('Completed in ' + str(elapsed) + ' minute(s).')


# ## Get NB runtime

# In[ ]:


#get time of end of code
endCodeTime = time.time()


# In[ ]:


elapseCodeTime = round(endCodeTime - startCodeTime,2)
print(round(elapseCodeTime/60, 2), 'min - total run time')
print(round((elapseCodeTime/60)/60, 2), 'hr - total run time')


# In[ ]:


secProw = round(elapseCodeTime/len(claims_data), 4)
print('this run took', secProw, 'secs per input table row')


# In[ ]:




