--QUESTION: HOW SHOULD WE UTILIZE THE MEMBER_CROSSWALK TO ENSURE ALL JOINS ARE APPROPRIATE? SPECIFICALLY IF MBR_ID FRO 834 TABLE JOINS TO CLAIMS MEMBER_ID

--region create temp tables with member dates (member roster dates & pdm dates created)
--get min member_date
DROP TABLE IF EXISTS member_dates_min;
CREATE LOCAL TEMP TABLE member_dates_min
ON COMMIT PRESERVE ROWS AS

--get all distinct members by client 
SELECT 
  DATA_SOURCE,
  CLIENT,
  MEMBER_ID
  --create a 'period' by using each unique stay_month
  --,STAY_ADMIT_DATE AS STAY_ADMIT_DATE 
  --create an 'enroll start date' by using the first stay admit date
  ,MIN(STAY_ADMIT_DATE) AS FIRST_ADMIT_DATE 
FROM MEDECON_PRD.PDM a
--only have in contract data
WHERE LEFT(a.CONTRACT_PERIOD,2)='CY'
GROUP BY 1,2,3--,4
;

--SELECT * FROM member_dates_min
--WHERE CLIENT = 'AMBETTER' AND MEMBER_ID='U9517014101'--'U9583038402'
--ORDER BY STAY_ADMIT_DATE
;


--SELECT COUNT(*) FROM member_dates_all;
--end region

--region create table with important dates for each member
DROP TABLE IF EXISTS member_dates;
CREATE LOCAL TEMP TABLE member_dates
ON COMMIT PRESERVE ROWS AS

SELECT
  m.DATA_SOURCE,
    m.CLIENT,
  m.MEMBER_ID,
  b.FIRST_ADMIT_DATE,
  m.STAY_ADMIT_DATE,
  DATEDIFF('day', b.FIRST_ADMIT_DATE, m.STAY_ADMIT_DATE) AS MEMBER_DAYS
   ,DATEDIFF('day', b.FIRST_ADMIT_DATE, m.STAY_ADMIT_DATE) +1 AS MEMBER_DAYS_AddOne
  ,ADD_MONTHS(m.STAY_ADMIT_DATE,-12) AS yr_prior
  --,ADD_MONTHS(m.PERIOD,-3) AS lag_3_month
  ,ADD_MONTHS(m.STAY_ADMIT_DATE,-6) AS sixMonth_prior
  --,ADD_MONTHS(m.PERIOD,-15) AS yr_prior_wLag
  ,ADD_MONTHS(m.STAY_ADMIT_DATE,-24) AS TWOyr_prior
   ,DATEDIFF('month',b.FIRST_ADMIT_DATE,m.STAY_ADMIT_DATE) AS MEMBER_MONTHS
  ,DATEDIFF('month',b.FIRST_ADMIT_DATE,m.STAY_ADMIT_DATE)+1 AS MEMBER_MONTHS_AddOne
FROM MEDECON_PRD.PDM AS m 
LEFT JOIN member_dates_min b
USING(DATA_SOURCE,CLIENT, MEMBER_ID)
--QUESTION: - should we use this filter or not here?
WHERE LEFT(m.CONTRACT_PERIOD,2)='CY' 
GROUP BY 1,2,3,4,5
  ;
  
--SELECT * FROM member_dates
--WHERE CLIENT = 'AMBETTER' AND MEMBER_ID='U9517014101'--'U9583038402'
--ORDER BY STAY_ADMIT_DATE
--;
--end region
--SELECT * FROM MEDECON_PRD.PDM WHERE CLIENT='WELLCARE' AND MEMBER_ID='11014394';
--SELECT * FROM member_dates WHERE CLIENT='WELLCARE' AND MBR_ID='11014394';
--region create 3 patient diligence markers  (NOTE - NEED TO ADD CLIENT SCOPE TABLES AS NEW CLIENTS ADDED)

--region create diligence markers
--region wellcare diligence
DROP TABLE IF EXISTS pat_dilg_counts_wc;
CREATE LOCAL TEMP TABLE pat_dilg_counts_wc
ON COMMIT PRESERVE ROWS AS

SELECT 
  MEMBER_ID
  ,FROM_DATE
  --flu flag
  ,MAX(CASE WHEN left(PROC_CODE,5) in ('90630','90653','90654','90655','90656','90657','90658','90660','90662','90672','90673','90674','90682','90685','90686','90687','90688','90689','90694','90756','Q2034','Q2035','Q2036','Q2037','Q2038','Q2039','G0008')
    THEN 1 ELSE 0 END) AS flu_flag 
    --annual wellness visit flag
  ,MAX(CASE WHEN left(PROC_CODE,5) in ('G0402','G0403','G0404','G0405','G0438','G0439','G0468')
    THEN 1 ELSE 0 END) AS awv_flag
    --office visit counts
  ,COUNT(DISTINCT CASE WHEN left(PROC_CODE,5) in  ('99201','99202','99203','99204','99205','99211','99212','99213','99214','99215') 
    THEN FROM_DATE ELSE NULL END) AS Office_Visit_Frequency
  ,'WELLCARE' AS CLIENT
FROM MEDECON_UW_WORK_PRD.WELLCARE_SCOPE_DATA_V4 
WHERE --filter table to make it run faster
  --flu visits
 ( left(PROC_CODE,5) in ('90630','90653','90654','90655','90656','90657','90658','90660','90662','90672','90673','90674','90682','90685','90686','90687','90688','90689','90694','90756','Q2034','Q2035','Q2036','Q2037','Q2038','Q2039','G0008')
  --annual wellness visits
  or left(PROC_CODE,5) in  ('G0402','G0403','G0404','G0405','G0438','G0439','G0468')
  --office visits
  or  left(PROC_CODE,5) in  ('99201','99202','99203','99204','99205','99211','99212','99213','99214','99215') )
   --AND MEMBER_ID='11014394'
GROUP BY 1,2
;
--end region
--region ambetter diligence
DROP TABLE IF EXISTS pat_dilg_counts_amb;
CREATE LOCAL TEMP TABLE pat_dilg_counts_amb
ON COMMIT PRESERVE ROWS AS

SELECT 
  MEMBER_ID
  ,FROM_DATE
  --flu flag
  ,MAX(CASE WHEN left(PROC_CODE,5) in ('90630','90653','90654','90655','90656','90657','90658','90660','90662','90672','90673','90674','90682','90685','90686','90687','90688','90689','90694','90756','Q2034','Q2035','Q2036','Q2037','Q2038','Q2039','G0008')
    THEN 1 ELSE 0 END) AS flu_flag 
    --annual wellness visit flag
  ,MAX(CASE WHEN left(PROC_CODE,5) in ('G0402','G0403','G0404','G0405','G0438','G0439','G0468')
    THEN 1 ELSE 0 END) AS awv_flag
    --office visit counts
  ,COUNT(DISTINCT CASE WHEN left(PROC_CODE,5) in  ('99201','99202','99203','99204','99205','99211','99212','99213','99214','99215') 
    THEN FROM_DATE ELSE NULL END) AS Office_Visit_Frequency
  ,'AMBETTER' AS CLIENT
FROM MEDECON_UW_WORK_PRD.AMBETTER_SCOPE_DATA 
WHERE --filter table to make it run faster
  --flu visits
 ( left(PROC_CODE,5) in ('90630','90653','90654','90655','90656','90657','90658','90660','90662','90672','90673','90674','90682','90685','90686','90687','90688','90689','90694','90756','Q2034','Q2035','Q2036','Q2037','Q2038','Q2039','G0008')
  --annual wellness visits
  or left(PROC_CODE,5) in  ('G0402','G0403','G0404','G0405','G0438','G0439','G0468')
  --office visits
  or  left(PROC_CODE,5) in  ('99201','99202','99203','99204','99205','99211','99212','99213','99214','99215') )
   --AND MEMBER_ID='11014394'
GROUP BY 1,2
;
--end region

--SELECT * FROM pat_dilg_counts_amb
--WHERE CLIENT = 'AMBETTER' AND MEMBER_ID='U9517014101'--'U9583038402'
--ORDER BY FROM_DATE
--;

--bring all client dilig tables together
DROP TABLE IF EXISTS pat_dilg_counts;
CREATE LOCAL TEMP TABLE pat_dilg_counts
ON COMMIT PRESERVE ROWS AS
(SELECT * FROM pat_dilg_counts_wc)
UNION ALL 
(SELECT * FROM pat_dilg_counts_amb)
;

--SELECT * FROM pat_dilg_counts_amb
--WHERE CLIENT = 'AMBETTER' AND MEMBER_ID='U9517014101'--'U9583038402'
--ORDER BY FROM_DATE
--;

--region check summary stats for this table
SELECT 
  CLIENT, 
  COUNT(DISTINCT FROM_DATE) AS dstnct_from_date, 
  SUM(CASE WHEN FROM_DATE IS NULL THEN 1 ELSE 0 END) AS null_count_from_date, 
  COUNT(*) AS all_counts,
  SUM(CASE WHEN FROM_DATE IS NULL THEN 1 ELSE 0 END)/COUNT(*)*100 AS null_prcnt_from_date
FROM pat_dilg_counts 
GROUP BY 1;
--check ambetter scope table as a whole
SELECT 
  COUNT(DISTINCT FROM_DATE) AS dstnct_from_date, 
  SUM(CASE WHEN FROM_DATE IS NULL THEN 1 ELSE 0 END) AS null_count_from_date, 
  COUNT(*) AS all_counts,
  SUM(CASE WHEN FROM_DATE IS NULL THEN 1 ELSE 0 END)/COUNT(*)*100 AS null_prcnt_from_date
FROM MEDECON_UW_WORK_PRD.AMBETTER_SCOPE_DATA 
;

--SELECT * FROM pat_dilg_counts WHERE CLIENT='WELLCARE' AND MEMBER_ID='11014394';
--end region
--end region

--end region 

--region bring all patient dilig data temp tables together

--region get all time patient dilig counts
DROP TABLE IF EXISTS pat_dilg_counts_all_1;
CREATE LOCAL TEMP TABLE pat_dilg_counts_all_1
ON COMMIT PRESERVE ROWS AS
SELECT 
  --get all member month data
  m.*

  --get patient diligence
    ,SUM(ZEROIFNULL(f.flu_flag)) as flu_counts
    ,SUM(ZEROIFNULL(f.awv_flag)) as awv_counts      
    ,SUM(ZEROIFNULL(f.Office_Visit_Frequency)) as Office_Visit_Counts
    --get patient dilig data by time
     ,SUM(ZEROIFNULL(f.flu_flag))/ MEMBER_MONTHS_AddOne AS flu_byMemMonths
,SUM(ZEROIFNULL(f.awv_flag))/ MEMBER_MONTHS_AddOne AS awv_byMemMonths
,SUM(ZEROIFNULL(f.Office_Visit_Frequency)) / MEMBER_MONTHS_AddOne AS ofv_byMemMonths
,SUM(ZEROIFNULL(f.flu_flag))/ MEMBER_DAYS_AddOne AS flu_byMemDays
,SUM(ZEROIFNULL(f.awv_flag))/ MEMBER_DAYS_AddOne AS awv_byMemDays
,SUM(ZEROIFNULL(f.Office_Visit_Frequency)) / MEMBER_DAYS_AddOne AS ofv_byMemDays

FROM member_dates m
--get all time data
LEFT JOIN pat_dilg_counts f
ON m.MEMBER_ID = f.MEMBER_ID AND f.CLIENT=m.CLIENT AND f.FROM_DATE BETWEEN m.FIRST_ADMIT_DATE AND m.STAY_ADMIT_DATE 

--GROUP BY ALL THINGS IN m*
GROUP BY 1,2,3,4,5,6,7,8,9,10,11,12
;

--SELECT * FROM pat_dilg_counts_all_1
--WHERE CLIENT = 'AMBETTER' AND MEMBER_ID='U9517014101'
--order bY DATA_SOURCE,STAY_ADMIT_dATE
--;
--end region

--SELECT * FROM pat_dilg_counts_all_1 WHERE CLIENT='WELLCARE' AND MBR_ID='11014394' order by ENROLL_START_PERIOD, PERIOD;

--region get recent patient dilig counts
DROP TABLE IF EXISTS pat_dilg_counts_all;
CREATE LOCAL TEMP TABLE pat_dilg_counts_all
ON COMMIT PRESERVE ROWS AS
SELECT 
m.*
--get RECENT patient dilig data by time
,SUM(ZEROIFNULL(fr.flu_flag)) as flu_counts_recent 
,SUM(ZEROIFNULL(fr.awv_flag)) as awv_counts_recent              
,SUM(ZEROIFNULL(fr.Office_Visit_Frequency)) as Office_Visit_Counts_recent
,SUM(ZEROIFNULL(fr.flu_flag))/ MEMBER_MONTHS_AddOne AS flu_byMemMonths_recent
,SUM(ZEROIFNULL(fr.awv_flag))/ MEMBER_MONTHS_AddOne AS awv_byMemMonths_recent
,SUM(ZEROIFNULL(fr.Office_Visit_Frequency))/ MEMBER_MONTHS_AddOne AS ofv_byMemMonths_recent
,SUM(ZEROIFNULL(fr.flu_flag))/ MEMBER_DAYS_AddOne AS flu_byMemDays_recent
,SUM(ZEROIFNULL(fr.awv_flag)) / MEMBER_DAYS_AddOne AS awv_byMemDays_recent
,SUM(ZEROIFNULL(fr.Office_Visit_Frequency))/ MEMBER_DAYS_AddOne AS ofv_byMemDays_recent
 --FROM --(
   --get recent data

--   SELECT 
--    m.*
--      ,SUM(ZEROIFNULL(fr.flu_flag)) as flu_counts_recent --over
----                         (partition by m.mbr_id, m.client
----                          order by  m.ENROLL_START_PERIOD, m.yr_prior, 
----                          rows between unbounded preceding and current row
----                         ) as flu_counts_recent
--      ,SUM(ZEROIFNULL(fr.awv_flag)) as awv_counts_recent  --over
----                         (partition by m.mbr_id, m.client
----                          order by m.ENROLL_START_PERIOD, m.yr_prior,
----                          rows between unbounded preceding and current row
----                         ) as awv_counts_recent   
--                         
--      ,SUM(ZEROIFNULL(fr.Office_Visit_Frequency)) as Office_Visit_Counts_recent --over
----                         (partition by m.mbr_id, m.client
----                          order by m.ENROLL_START_PERIOD, m.yr_prior,
----                          rows between unbounded preceding and current row
----                         ) as Office_Visit_Counts_recent
--    
  
FROM pat_dilg_counts_all_1 m
--LEFT JOIN --3 variable table (flu, owv, awv)
--ON BETWEEN --whatever timeframe 
  ----get recent data
  ----uses from dates 1 yr prior to period
LEFT JOIN pat_dilg_counts fr
ON fr.CLIENT=m.CLIENT AND m.MEMBER_ID = fr.MEMBER_ID 
AND fr.FROM_DATE BETWEEN m.yr_prior AND m.STAY_ADMIT_DATE
--WHERE m.CLIENT='WELLCARE' AND MBR_ID='11014394'
  --GROUP BY ALL THINGS IN m* AND flags
GROUP BY 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21--,22,23--,24,25,26
;
--end region

--SELECT * FROM pat_dilg_counts_all
--WHERE CLIENT = 'AMBETTER' AND MEMBER_ID='U9517014101'
--order bY DATA_SOURCE,STAY_ADMIT_dATE
--;
--SELECT * FROM pat_dilg_counts_all WHERE CLIENT='WELLCARE' AND MBR_ID='11014394' order by ENROLL_START_PERIOD, PERIOD;


--drop unneeded tables
DROP TABLE IF EXISTS member_dates;
DROP TABLE IF EXISTS pat_dilg_counts;
DROP TABLE IF EXISTS pat_dilg_counts_wc;
DROP TABLE IF EXISTS pat_dilg_counts_amb;
DROP TABLE IF EXISTS pat_dilg_counts_all_1;
--end region


--region create patient historical data features

--region create streak/no streak, snf_hist etc. features for pat_hist 
--QUESTION: CAN WE MAKE THE PAT_HIST TABLE CREATION PROCESS FASTER?
--create streak_flag and grouping columns
DROP TABLE IF EXISTS pat_hist_streaks;
CREATE LOCAL TEMP TABLE pat_hist_streaks
ON COMMIT PRESERVE ROWS AS
SELECT
  DATA_SOURCE
  ,CLIENT
  ,MEMBER_ID
  ,PAC_STY_ID
  ,STAY_ADMIT_DATE
   --,EPI_IS_READMIT_90_DAY as Streak_flag
  ,MAX(EPI_IS_READMIT_90_DAY) as readmit90_flag
  --sums how many No streaks (NO readmit90s) they've had
  --max function is same as streak_flag feature
  ,sum(case when (MAX(EPI_IS_READMIT_90_DAY)) = 0 then 1 else 0 end) over
                       (partition by data_source,client, member_id
                        order by pac_sty_id
                        rows between unbounded preceding and current row
                       ) as grouping

  --get patient historical claims data
  --for each month, see how many distinct stays they've had
  ,COUNT(*) as Count_pac_sty_id 
   --if discharged to a snf more than 1x then 1 else 0
  --,SUM(case when POS = '31' and (STAY_ADMIT_DATE-1) - PRIOR_STAY_DISCHARGE_DATE <= 3 then 1 else 0 end) as snf_hist 
--count the number of readmits by stay month
 ,SUM(EPI_IS_READMIT_90_DAY) AS hist_readmit_90
         
FROM MEDECON_PRD.PDM
--only for hos visits that are in scope
WHERE POS='21' AND LEFT(CONTRACT_PERIOD,2)='CY'
GROUP BY 1,2,3,4,5
--ORDER BY MEMBER_ID
;

--SELECT * FROM pat_hist_streaks
--WHERE (CLIENT = 'WELLCARE' AND member_id='070054078');

--create streak_90 column
DROP TABLE IF EXISTS pat_hist_streaks_2;
CREATE LOCAL TEMP TABLE pat_hist_streaks_2
ON COMMIT PRESERVE ROWS AS
SELECT 
  *
  ,(case when readmit90_flag  = 0 then 0
          --how many times have they admitted without a readmit in a row
           else row_number() over (partition by data_source,client, member_id, grouping order by pac_sty_id) - 1
           end) as Streak_90

FROM pat_hist_streaks
--WHERE MEMBER_ID='002001561'
--ORDER BY PAC_STY_ID--MEMBER_ID
;

--SELECT * FROM pat_hist_streaks_2
--WHERE (CLIENT = 'WELLCARE' AND member_id='070054078');
--SELECT * FROM pat_hist_streaks_2 WHERE CLIENT='WELLCARE' AND MEMBER_ID='11014394';
--drop unneeded tables
DROP TABLE IF EXISTS pat_hist_streaks;

--end region 

--SELECT * FROM pat_hist_streaks_2
----WHERE MEMBER_ID='002001561'
--WHERE CLIENT = 'AMBETTER' AND MEMBER_ID='U9517014101'
--order bY DATA_SOURCE,STAY_ADMIT_dATE
--;

--group by stay date to get in same format as other patient hist table
DROP TABLE IF EXISTS pat_hist_data;
CREATE LOCAL TEMP TABLE pat_hist_data
ON COMMIT PRESERVE ROWS AS
--QUESTION - could get rid of this yet? (NO - THERE ARE SOME STAY_ADMIT_DATE etc. with multiple pac_Sty_ids)
SELECT 
  DATA_SOURCE
  ,CLIENT
  ,MEMBER_ID
  ,STAY_ADMIT_DATE
  ,MAX(readmit90_FLAG) AS readmit90_flag
  ,MAX(GROUPING) AS grouping_noReadmitsMAX
  ,MAX(STREAK_90) AS Streak_90
  ,SUM(Count_pac_sty_id ) AS Count_pac_sty_id 
  --,MAX(snf_hist) AS snf_hist
  ,SUM(hist_readmit_90) AS hist_readmit_90
FROM pat_hist_streaks_2
GROUP BY 1,2,3,4
;
--drop unneeded tables
DROP TABLE IF EXISTS pat_hist_streaks_2;
--end region

--SELECT * FROM pat_hist_data
----WHERE MEMBER_ID='0035916109'AND CLIENT = 'WELLCARE' --streak_90 > 2 LIMIT 100
--WHERE CLIENT = 'AMBETTER' AND MEMBER_ID='U9517014101'
----(CLIENT = 'WELLCARE' AND member_id='070054078')
--order bY DATA_SOURCE,STAY_ADMIT_dATE
--
--;



--SELECT * FROM pat_hist_data WHERE CLIENT='WELLCARE' AND MEMBER_ID='11014394';

--region add in historical claims data to full table
--creates count_180 & 365 and total admit columns 


DROP TABLE IF EXISTS pat_hist_AND_dilig_1;
CREATE LOCAL TEMP TABLE pat_hist_AND_dilig_1
ON COMMIT PRESERVE ROWS AS

SELECT 
  --get all member month AND patient diligence data
  m.*
 --get patient historical claims data
  --get total admit counts (no date filters)
  ,SUM(ZEROIFNULL(g.Count_pac_sty_id ))  as total_admit_count --TOTAL HOS in contract admit counts
  ,SUM(ZEROIFNULL(g.Count_pac_sty_id)) / MEMBER_MONTHS_AddOne AS total_admit_count_byMemMonths --see ratio by member months
  ,SUM(ZEROIFNULL(g.Count_pac_sty_id))  / MEMBER_DAYS_AddOne AS total_admit_count_byMemDays --see ratio by member days
  
  --get historical readmit rate by patient
  ,SUM(ZEROIFNULL(g.hist_readmit_90))/MEMBER_MONTHS_AddOne AS hist_readmit_90_rate_byMemMonths
   ,SUM(ZEROIFNULL(g.hist_readmit_90))/MEMBER_DAYS_AddOne AS hist_readmit_90_rate_byMemDays
  --bring in streak columns
  --,MAX(g.readmit90_flag) AS readmit90_flag
 -- ,MAX(g.grouping_noReadmitsMAX) AS grouping_noReadmitsMAX
  ,MAX(g.Streak_90) AS Streak_90
   --if never admitted before then 0.
  ,case when SUM(g.Count_pac_sty_id )-1 = 0 then 0
        --if they have had a streak of non readmissions 
        when MAX(g.streak_90) >= 1 then 2
        --if no streak of non readmits (ie. max_streak_90 is 0
        when MAX(g.streak_90) = 0 then 1
        --covers rows with no admits
        else 0
        end as No_Streak
FROM pat_dilg_counts_all m
--count total admit counts from enroll start date to the period
LEFT join pat_hist_data g 
on g.DATA_SOURCE = m.DATA_SOURCE AND g.CLIENT = m.CLIENT AND g.MEMBER_ID = m.MEMBER_ID  AND g.STAY_ADMIT_DATE BETWEEN m.FIRST_ADMIT_DATE AND m.STAY_ADMIT_DATE 
--GROUP BY ALL THINGS IN m* (member dates data & patient hist data)
--AND DATA_SOURCE
GROUP BY 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30--,31,32,33
;
--SELECT * FROM pat_hist_AND_dilig_1 WHERE CLIENT='WELLCARE' AND MBR_ID='11014394' ORDER BY ENROLL_START_PERIOD, PERIOD;

--SELECT * FROM pat_hist_AND_dilig_1
----WHERE MEMBER_ID='0035916109'AND CLIENT = 'WELLCARE' 
--WHERE CLIENT = 'AMBETTER' AND MEMBER_ID='U9517014101'
----(CLIENT = 'WELLCARE' AND member_id='070054078')
--order bY DATA_SOURCE,STAY_ADMIT_dATE
--;

--region check no streak is working
--see 0,1,3 are there
--SELECT No_Streak, count(*) FROM pat_hist_AND_dilig_1
--GROUP BY 1;
----find someone with no streak = 1
--SELECT DATA_SOURCE, CLIENT, MEMBER_ID, COUNT(*)
--FROM pat_hist_AND_dilig_1
--WHERE NO_STREAK = 1
--GROUP BY 1,2,3
--LIMIT 100
--;
----look at 1 member
--SELECT * FROM pat_hist_AND_dilig_1
--WHERE MEMBER_ID='U9030184201' AND CLIENT='AMBETTER'
--order bY DATA_SOURCE,STAY_ADMIT_dATE
--;
--
----look at 1 patient in 2 tables
--SELECT * 
--FROM pat_dilg_counts_all m
--WHERE MEMBER_ID='U9030184201' AND CLIENT='AMBETTER'
--order bY DATA_SOURCE,STAY_ADMIT_dATE
--;
--SELECT * 
--FROM pat_hist_data g 
--WHERE MEMBER_ID='U9030184201' AND CLIENT='AMBETTER'
--order bY DATA_SOURCE,STAY_ADMIT_dATE
;
--end region 




DROP TABLE IF EXISTS pat_dilg_counts_all;

DROP TABLE IF EXISTS pat_hist_AND_dilig_2;
CREATE LOCAL TEMP TABLE pat_hist_AND_dilig_2
ON COMMIT PRESERVE ROWS AS

SELECT 
  --get all member month AND patient diligence data
  m.*
   --6 month lookback 
  ,SUM(ZEROIFNULL(c.Count_pac_sty_id))  as Count_180 --HOS visits in last 6 months 
  ,SUM(ZEROIFNULL(c.Count_pac_sty_id)) / MEMBER_MONTHS_AddOne AS Count_180_byMemMonths --see ratio by member months
  ,SUM(ZEROIFNULL(c.Count_pac_sty_id))/ MEMBER_DAYS_AddOne AS Count_180_byMemDays --see ratio by member days


FROM pat_hist_AND_dilig_1 m
--these 2 joins for count 180/365 fields
LEFT join pat_hist_data c 
on c.CLIENT = m.CLIENT AND c.DATA_SOURCE = m.DATA_SOURCE AND c.MEMBER_ID = m.MEMBER_ID and c.STAY_ADMIT_DATE between m.sixMonth_prior and m.STAY_ADMIT_DATE 
--GROUP BY ALL THINGS IN m* (member dates data & patient hist data)
--AND DATA_SOURCE
GROUP BY 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37--,38,39,40,41,42
;

--SELECT * FROM pat_hist_AND_dilig_2
----WHERE MEMBER_ID='0035916109'AND CLIENT = 'WELLCARE' 
--WHERE CLIENT = 'AMBETTER' AND MEMBER_ID='U9517014101'
----(CLIENT = 'WELLCARE' AND member_id='070054078')
--order bY DATA_SOURCE,STAY_ADMIT_dATE
--;
--
--SELECT * FROM pat_hist_data
----WHERE MEMBER_ID='0035916109'AND CLIENT = 'WELLCARE' 
--WHERE-- CLIENT = 'AMBETTER' AND MEMBER_ID='U9517014101'
--(CLIENT = 'WELLCARE' AND member_id='070054078')
--order bY DATA_SOURCE,STAY_ADMIT_dATE
--;

--SELECT * FROM pat_hist_AND_dilig_2 WHERE CLIENT='WELLCARE' AND MBR_ID='11014394' ORDER BY ENROLL_START_PERIOD, PERIOD;
DROP TABLE IF EXISTS pat_hist_AND_dilig_1;


DROP TABLE IF EXISTS pat_hist_AND_dilig_3;
CREATE LOCAL TEMP TABLE pat_hist_AND_dilig_3
ON COMMIT PRESERVE ROWS AS
SELECT
  m.*
  --12 month lookback
  ,SUM(ZEROIFNULL(d.Count_pac_sty_id)) as Count_365 --HOS visits in last 12 months 
  ,SUM(ZEROIFNULL(d.Count_pac_sty_id ))/ MEMBER_MONTHS_AddOne AS Count_365_byMemMonths --see ratio by member months
  ,SUM(ZEROIFNULL(d.Count_pac_sty_id ))/ MEMBER_DAYS_AddOne AS Count_365_byMemDays --see ratio by member days

FROM pat_hist_AND_dilig_2 m
LEFT join pat_hist_data d 
on  d.CLIENT = m.CLIENT AND d.DATA_SOURCE = m.DATA_SOURCE AND d.MEMBER_ID = m.MEMBER_ID and d.STAY_ADMIT_DATE between m.yr_prior and m.STAY_ADMIT_DATE
--GROUP BY ALL THINGS IN m* (member dates data & patient hist data)
GROUP BY 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40--,41,42,43,44,45
;

--SELECT * FROM pat_hist_AND_dilig_3
----WHERE MEMBER_ID='0035916109'AND CLIENT = 'WELLCARE' 
--WHERE CLIENT = 'AMBETTER' AND MEMBER_ID='U9517014101'
--order bY DATA_SOURCE,STAY_ADMIT_dATE
--;


DROP TABLE IF EXISTS pat_hist_AND_dilig_2;

--create table that has snf hist for each patient
DROP TABLE IF EXISTS pat_snf_hist_;
CREATE LOCAL TEMP TABLE pat_snf_hist
ON COMMIT PRESERVE ROWS AS 
SELECT
  DATA_SOURCE
  ,CLIENT
  ,MEMBER_ID
  ,STAY_ADMIT_DATE AS SNF_ADMIT_DATE
  --UPDATE COULD USE EPI_HOS_DISCHARGE DATE instead of prior stay discharge date for hos to snf
  ,SUM(case when (STAY_ADMIT_DATE-1) - PRIOR_STAY_DISCHARGE_DATE <= 3 then 1 else 0 end) as snf_hist 
FROM MEDECON_PRD.PDM
WHERE POS='31'
GROUP BY 1,2,3,4
;

--SELECT * FROM pat_snf_hist
----WHERE MEMBER_ID='0035916109'AND CLIENT = 'WELLCARE' 
--WHERE CLIENT = 'AMBETTER' AND MEMBER_ID='U9517014101'
--order bY DATA_SOURCE,SNF_ADMIT_dATE
--;

--count snf hist stays up to this hospital visit (non inclusive)
--QUESTION: should upper bound of between join be PRIOR_EPI_HOS_DISCHARGE_DATE?
DROP TABLE IF EXISTS pat_hist_AND_dilig;
CREATE LOCAL TEMP TABLE pat_hist_AND_dilig
ON COMMIT PRESERVE ROWS AS
SELECT
  m.*
  --counts of if discharged to a snf more than in last 2 years 
  ,SUM(ZEROIFNULL(e.snf_hist )) AS snf_hist
FROM pat_hist_AND_dilig_3 m
LEFT join pat_snf_hist e 
on e.CLIENT = m.CLIENT AND e.DATA_SOURCE = m.DATA_SOURCE AND e.MEMBER_ID = m.MEMBER_ID and e.SNF_ADMIT_DATE between m.TWOyr_prior and m.STAY_ADMIT_DATE 
--GROUP BY ALL THINGS IN m* (member dates data & patient hist data)
GROUP BY 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43--,44,45,46,47,48
;

--SELECT * FROM pat_hist_AND_dilig
----WHERE MEMBER_ID='0035916109'AND CLIENT = 'WELLCARE' 
--WHERE CLIENT = 'AMBETTER' AND MEMBER_ID='U9517014101'
--order bY DATA_SOURCE,STAY_ADMIT_dATE
--;

DROP TABLE IF EXISTS pat_hist_AND_dilig_3;

--end region 
--SELECT * FROM pat_hist_AND_dilig WHERE CLIENT='WELLCARE' AND MBR_ID='11014394';

--region bring in patient's historical dx_risks 
--region create patient hist dx risk scores
--max dx code rr is historical dx rr 
DROP TABLE IF EXISTS dx_hist_pats;
CREATE LOCAL TEMP TABLE dx_hist_pats
ON COMMIT PRESERVE ROWS AS 
select 
a.DATA_SOURCE
,a.CLIENT
,a.member_id
,a.STAY_ADMIT_DATE
--GET HIGHEST DX RISK UP TO THAT STAY_ADMIT_daTE_MONTH
,max(b.Adj_DX_1_RR) AS MAX_Adj_DX_1_RR --partion by a.DATA_SOURCE ,a.CLIENT,a.member_id 
  --ORDER BY stay_admit_date_month
 --ROWS BETWEN Unbounced preceding.. 
,max(c.Adj_DX_2_RR) AS MAX_Adj_DX_2_RR
,max(d.Adj_DX_3_RR) AS MAX_Adj_DX_3_RR
--do same for snf dx rate
,max(b.Adj_DX_1_SNF_rate) AS MAX_Adj_DX_1_SNF_rate
,max(c.Adj_DX_2_SNF_rate) AS MAX_Adj_DX_2_SNF_rate
,max(d.Adj_DX_3_SNF_rate) AS MAX_Adj_DX_3_SNF_rate
--,max(b.Adj_DX_1_RR) OVER (PARTITION BY a.DATA_SOURCE, a.CLIENT, MEMBER_ID ORDER BY DATE_TRUNC('MONTH',STAY_ADMIT_DATE) rows between unbounded preceding and current row) as Historical_DX1_readmission_risk
--,max(c.Adj_DX_2_RR) OVER (PARTITION BY a.DATA_SOURCE, a.CLIENT, MEMBER_ID ORDER BY DATE_TRUNC('MONTH',STAY_ADMIT_DATE) rows between unbounded preceding and current row) as Historical_DX2_readmission_risk
--,max(d.Adj_DX_3_RR) OVER (PARTITION BY a.DATA_SOURCE, a.CLIENT, MEMBER_ID ORDER BY DATE_TRUNC('MONTH',STAY_ADMIT_DATE) rows between unbounded preceding and current row) as Historical_DX3_readmission_risk

FROM MEDECON_PRD.PDM AS a
LEFT JOIN DATALAB_WORK_PRD.DX_RISKS b
ON a.DATA_SOURCE=b.DATA_SOURCE AND a.CLIENT=b.CLIENT AND a.DX1=b.DX 
LEFT JOIN DATALAB_WORK_PRD.DX_RISKS c
ON a.DATA_SOURCE=c.DATA_SOURCE AND a.CLIENT=c.CLIENT AND a.DX2=c.DX 
LEFT JOIN DATALAB_WORK_PRD.DX_RISKS d
ON a.DATA_SOURCE=d.DATA_SOURCE AND a.CLIENT=d.CLIENT AND a.DX3=d.DX
WHERE LEFT(a.CONTRACT_PERIOD,2)='CY'
GROUP BY 1,2,3,4
;

--SELECT * FROM dx_hist_pats
----WHERE MEMBER_ID='0035916109'AND CLIENT = 'WELLCARE' 
--WHERE CLIENT = 'AMBETTER' AND MEMBER_ID='U9517014101'
--order bY DATA_SOURCE,STAY_ADMIT_dATE
--;


--SELECT * FROM DATALAB_WORK_PRD.DX_RISKS 
--WHERE CLIENT = 'WELLCARE' AND DX IN(
--'E871',	'N179',	'N2581',
--'I130',	'I5033',	'N184',
--'I214',	'J690',	'J189',
--'I611',	'N179',	'I5032',
--'G9340',	'F0390',	'I69828',
--'G9341',	'G936',	'I619',
--'K2961',	'I5033',	'G9341')
--AND DATA_SOURCE='CLAIM'
--;

--get the max rates up to that point for each member
DROP TABLE IF EXISTS dx_hist_pats_2;
CREATE LOCAL TEMP TABLE dx_hist_pats_2
ON COMMIT PRESERVE ROWS AS 
SELECT *
,max(b.MAX_Adj_DX_1_RR) OVER (PARTITION BY b.DATA_SOURCE, b.CLIENT, b.MEMBER_ID ORDER BY b.STAY_ADMIT_DATE rows between unbounded preceding and current row) as Historical_DX1_readmission_risk
,max(b.MAX_Adj_DX_2_RR) OVER (PARTITION BY b.DATA_SOURCE, b.CLIENT, b.MEMBER_ID ORDER BY b.STAY_ADMIT_DATE rows between unbounded preceding and current row) as Historical_DX2_readmission_risk
,max(b.MAX_Adj_DX_3_RR) OVER (PARTITION BY b.DATA_SOURCE, b.CLIENT, b.MEMBER_ID ORDER BY b.STAY_ADMIT_DATE rows between unbounded preceding and current row) as Historical_DX3_readmission_risk
,max(b.MAX_Adj_DX_1_SNF_rate) OVER (PARTITION BY b.DATA_SOURCE, b.CLIENT, b.MEMBER_ID ORDER BY b.STAY_ADMIT_DATE rows between unbounded preceding and current row) as Historical_DX1_SNF_risk
,max(b.MAX_Adj_DX_2_SNF_rate) OVER (PARTITION BY b.DATA_SOURCE, b.CLIENT, b.MEMBER_ID ORDER BY b.STAY_ADMIT_DATE rows between unbounded preceding and current row) as Historical_DX2_SNF_risk
,max(b.MAX_Adj_DX_3_SNF_rate) OVER (PARTITION BY b.DATA_SOURCE, b.CLIENT, b.MEMBER_ID ORDER BY b.STAY_ADMIT_DATE rows between unbounded preceding and current row) as Historical_DX3_SNF_risk
FROM dx_hist_pats b;

--SELECT * FROM dx_hist_pats_2
----WHERE MEMBER_ID='0035916109'AND CLIENT = 'WELLCARE' 
--WHERE CLIENT = 'AMBETTER' AND MEMBER_ID='U9517014101'
--order bY DATA_SOURCE,STAY_ADMIT_dATE
--;

DROP TABLE IF EXISTS dx_hist_pats;
--SELECT * FROM dx_hist_pats_2 WHERE CLIENT='WELLCARE' AND MEMBER_ID='11014394';
--end region


--region bring in patients hist dx codes to full table 
DROP TABLE IF EXISTS dx_hist_pats_AND_dilig;
CREATE LOCAL TEMP TABLE dx_hist_pats_AND_dilig
ON COMMIT PRESERVE ROWS AS 
SELECT 
a.*
,b.Historical_DX1_readmission_risk
,b.Historical_DX2_readmission_risk
,b.Historical_DX3_readmission_risk
,b.MAX_Adj_DX_1_RR 
,b.MAX_Adj_DX_2_RR 
,b.MAX_Adj_DX_3_RR 
,b.Historical_DX1_SNF_risk
,b.Historical_DX2_SNF_risk
,b.Historical_DX3_SNF_risk
,b.MAX_Adj_DX_1_SNF_rate 
,b.MAX_Adj_DX_2_SNF_rate
,b.MAX_Adj_DX_3_SNF_rate
FROM pat_hist_AND_dilig a
LEFT JOIN dx_hist_pats_2 b
--USING(DATA_SOURCE, CLIENT, MEMBER_ID, STAY_ADMIT_DATE)
ON a.DATA_SOURCE = b.DATA_SOURCE
AND a.CLIENT = b.CLIENT
AND a.MEMBER_ID = b.member_id
AND b.STAY_ADMIT_DATE= a.STAY_ADMIT_DATE
;

--SELECT * FROM dx_hist_pats_AND_dilig
----WHERE MEMBER_ID='0035916109'AND CLIENT = 'WELLCARE' 
--WHERE CLIENT = 'AMBETTER' AND MEMBER_ID='U9517014101'
--order bY DATA_SOURCE,STAY_ADMIT_dATE
--;


DROP TABLE IF EXISTS pat_hist_AND_dilig;
DROP TABLE IF EXISTS dx_hist_pats_2;
--end region
--end region


--region bring in charlson comoborbidity index AND creates static table 
--note the charlson comobord index is created from a downstream table (DATALAB_WORK_PRD.PATIENT_DX_HISTORY)
--flagging here if this causes issues in futuree
DROP TABLE IF EXISTS DATALAB_WORK_PRD.PATIENT_HISTORICAL_AND_DILIGENCE_DEV;
CREATE  TABLE DATALAB_WORK_PRD.PATIENT_HISTORICAL_AND_DILIGENCE_DEV AS 
SELECT *
FROM dx_hist_pats_AND_dilig a
LEFT JOIN DATALAB_PRD.Charlson_Comorbidity_Index_Patient_History_DEV b
USING(DATA_SOURCE, CLIENT, MEMBER_ID, FIRST_ADMIT_DATE, STAY_ADMIT_DATE)
;

DROP TABLE IF EXISTS dx_hist_pats_AND_dilig ;
--end region



--SELECT * FROM DATALAB_PRD.Charlson_Comorbidity_Index_Patient_History_DEV
----WHERE MEMBER_ID='0035916109'AND CLIENT = 'WELLCARE' --streak_90 > 2 LIMIT 100
--WHERE CLIENT = 'AMBETTER' AND MEMBER_ID='U9517014101'
--order bY DATA_SOURCE,STAY_ADMIT_dATE
--;
--
--SELECT * FROM DATALAB_WORK_PRD.PATIENT_HISTORICAL_AND_DILIGENCE_DEV
----WHERE MEMBER_ID='0035916109'AND CLIENT = 'WELLCARE' --streak_90 > 2 LIMIT 100
--WHERE CLIENT = 'AMBETTER' AND MEMBER_ID='U9517014101'
--order bY DATA_SOURCE,STAY_ADMIT_dATE
--;

--SELECT * FROM DATALAB_WORK_PRD.PATIENT_HISTORICAL_AND_DILIGENCE WHERE CLIENT='WELLCARE' AND MBR_ID='11014394';


--region explore model inputs from daily run

--end region
