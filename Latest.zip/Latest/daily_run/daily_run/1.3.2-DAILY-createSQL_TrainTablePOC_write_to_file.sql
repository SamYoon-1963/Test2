--region creates base table 
 DROP TABLE IF EXISTS base_pat_table; 
 CREATE LOCAL TEMPORARY TABLE base_pat_table ON COMMIT PRESERVE ROWS AS
      
 select 
 a.* 
       ,case when a.NEXT_POS = '12' and (a.NEXT_STAY_ADMIT_DATE-1) - a.STAY_DISCHARGE_DATE <= 7 then 'Home With Care' 
          when a.NEXT_POS = '31' and (a.NEXT_STAY_ADMIT_DATE-1) - a.STAY_DISCHARGE_DATE <= 3 then 'SNF' 
       when a.NEXT_POS = '61' and (a.NEXT_STAY_ADMIT_DATE-1) - a.STAY_DISCHARGE_DATE <= 3  then 'IRF' 
       when a.NEXT_POS = 'LTAC' and (a.NEXT_STAY_ADMIT_DATE-1) - a.STAY_DISCHARGE_DATE <= 3 then 'LTAC' 
       when a.NEXT_POS = '21' and (a.NEXT_STAY_ADMIT_DATE-1) - a.STAY_DISCHARGE_DATE <= 3 then 'Hospital' 
       else 'Home Without Care' 
       end as Discharge_To 
 --Create Readmission Flag 
 ,EPI_HAS_READMIT_90_DAY as Readmit_90 
 ,NEXT_EPI_HOS_ADMIT_DATE as next_stay_admit_date_calc 
 ,PRIOR_EPI_HOS_DISCHARGE_DATE as prior_stay_discharge_date_calc  
 --get stay admit date month for later joins 
 --3 MONTH PRIOR TO JOIN TO HISTORICAL TABLE 
 --,DATE_TRUNC('MONTH',STAY_ADMIT_DATE) AS PERIOD --UPDATE REMOVE PERIOD
 --these columns for using join to make final table dynamic to column changes in other tables 
 --,MEMBER_ID AS MBR_ID --UPDATE REMOVE PERIOD
 ,FACILITY_NPI AS NPI 
 ,STAY_ADMIT_DATE AS STAY_ADMIT_DATE_HIST 
 from MEDECON_PRD.PDM a  
 where  
 a.days < 100 --Patients that have a LOS greater than 100 are likely to skew data 
 and a.POS = '21' --Flags Hospital Stays 
 and a.STAYS = 1 --PDM Field Only, in place of a.PAC_STY_ID is not null and a.TOTAL_ALWD > 0 --Allowed amount greater than 0 per Scott O 
 and a.SCOPE_FLAG = 1 
AND LEFT(CONTRACT_PERIOD,2)='CY' 
 ;
 --add in icd description search table to base table
DROP TABLE IF EXISTS base_pat_table2; 
CREATE LOCAL TEMPORARY TABLE base_pat_table2 ON COMMIT PRESERVE ROWS AS
SELECT *
FROM base_pat_table
LEFT JOIN DATALAB_PRD.ICD_Descrip_search_DEV
USING(DATA_SOURCE, CLIENT, MEMBER_ID, PAC_STY_ID)
;
--end region
--region BRINGS IN Historical patient data and patient diligence data
--(COUNT_180, COUNT_365, SNF_Hist, Total Admit Count, streak features, HISTROICAL DX RISK FIELDS etc.)
--ALTER VIEW DATALAB_WORK_PRD.PATIENT_HISTORICAL_AND_DILIGENCE_WIDE_VIEW_DEV
--RENAME COLUMN STAY_ADMIT_DATE_HIST TO STAY_ADMIT_DATE;

DROP TABLE IF EXISTS pat_hist_vars; 
CREATE LOCAL TEMPORARY TABLE pat_hist_vars ON COMMIT PRESERVE ROWS AS

select
*
,CASE WHEN a.Discharge_To='SNF' THEN 1 ELSE 0 END AS SNF
,CASE WHEN a.Discharge_To='IRF' THEN 1  WHEN Discharge_To='SNF' THEN 1  ELSE 0 END AS SNF_or_IRF
from base_pat_table2 a
--bring in pat hist data
LEFT JOIN  DATALAB_PRD.PATIENT_HISTORICAL_AND_DILIGENCE_WIDE_VIEW_DEV b
USING(CLIENT, MEMBER_ID, STAY_ADMIT_DATE_HIST) --was STAY_ADMIT_DAT_HIST from view
--bring in npi risks fields
LEFT JOIN DATALAB_WORK_PRD.NPI_RISKS_WIDE_DEV c
USING(NPI, POS) 
;

--ALTER VIEW DATALAB_WORK_PRD.PATIENT_HISTORICAL_AND_DILIGENCE_WIDE_VIEW_DEV
--RENAME COLUMN STAY_ADMIT_DATE TO STAY_ADMIT_DATE_HIST ;

--end region
--region BRING in DX Risk Fields, SNF Discharge Risk & create final static table for training
DROP TABLE IF EXISTS DATALAB_WORK_PRD.POC_TRAINING_DATA_DEV;
CREATE TABLE DATALAB_WORK_PRD.POC_TRAINING_DATA_DEV AS 
select
  a.*
,b.Adj_DX_1_RR_CLAIMS
,b.Adj_DX_1_RR_OPS
,b.Adj_DX_1_SNF_rate_CLAIMS
,b.Adj_DX_1_SNF_rate_OPS
,b.dx1_counts_CLAIMS
,b.dx1_counts_OPS
,c.Adj_DX_2_RR_CLAIMS
,c.Adj_DX_2_RR_OPS
,c.Adj_DX_2_SNF_rate_CLAIMS
,c.Adj_DX_2_SNF_rate_OPS
,c.dx2_counts_CLAIMS
,c.dx2_counts_OPS
,d.Adj_DX_3_RR_CLAIMS
,d.Adj_DX_3_RR_OPS
,d.Adj_DX_3_SNF_rate_CLAIMS
,d.Adj_DX_3_SNF_rate_OPS
,d.dx3_counts_CLAIMS
,d.dx3_counts_OPS
FROM pat_hist_vars a
LEFT JOIN DATALAB_WORK_PRD.DX_RISKS_WIDE b
ON a.CLIENT = b.CLIENT AND a.DX1 = b.DX
LEFT JOIN DATALAB_WORK_PRD.DX_RISKS_WIDE c
ON a.CLIENT = c.CLIENT AND a.DX2 = c.DX
LEFT JOIN DATALAB_WORK_PRD.DX_RISKS_WIDE  d
ON a.CLIENT = d.CLIENT AND a.DX3 = d.DX;
--end region
