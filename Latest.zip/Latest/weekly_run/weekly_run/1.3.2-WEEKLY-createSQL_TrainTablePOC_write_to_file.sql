--REGION create OPS & CLAIMS HIST DATA tables SPLIT BY COLUMN 
--npi table
DROP TABLE IF EXISTS DATALAB_WORK_PRD.NPI_RISKS_WIDE_DEV; 
CREATE TABLE  DATALAB_WORK_PRD.NPI_RISKS_WIDE_DEV AS 
SELECT
   COALESCE(c.NPI,o.NPI) AS NPI 
   ,COALESCE(c.POS,o.POS) AS POS --UPDATE addeded POS 


   ,c.data_source_rr_rate AS data_source_rr_rate_CLAIMS
   ,o.data_source_rr_rate AS data_source_rr_rate_OPS
   ,c.Adj_NPI_risk AS Adj_NPI_risk_CLAIMS
   ,o.Adj_NPI_risk AS Adj_NPI_risk_OPS
   ,c.NPI_risk AS NPI_risk_CLAIMS
   ,o.NPI_risk AS NPI_risk_OPS
FROM ( select * FROM DATALAB_WORK_PRD.NPI_RISKS_DEV WHERE DATA_SOURCE='CLAIM' ) c 
 FULL OUTER JOIN (
 select * FROM DATALAB_WORK_PRD.NPI_RISKS_DEV WHERE DATA_SOURCE='OPERATIONAL') o 
 USING (NPI, POS); --UPDATE addeded POS

--dx table
DROP TABLE IF EXISTS DATALAB_WORK_PRD.DX_RISKS_WIDE; 
CREATE TABLE DATALAB_WORK_PRD.DX_RISKS_WIDE AS 
SELECT
  COALESCE(c.CLIENT,o.CLIENT) AS CLIENT, COALESCE(c.DX,o.DX) AS DX 


   ,c.Adj_DX_1_RR AS Adj_DX_1_RR_CLAIMS
   ,o.Adj_DX_1_RR AS Adj_DX_1_RR_OPS
   ,c.Adj_DX_2_RR AS Adj_DX_2_RR_CLAIMS
   ,o.Adj_DX_2_RR AS Adj_DX_2_RR_OPS
   ,c.Adj_DX_3_RR AS Adj_DX_3_RR_CLAIMS
   ,o.Adj_DX_3_RR AS Adj_DX_3_RR_OPS
   ,c.Adj_DX_1_SNF_rate AS Adj_DX_1_SNF_rate_CLAIMS
   ,o.Adj_DX_1_SNF_rate AS Adj_DX_1_SNF_rate_OPS
   ,c.Adj_DX_2_SNF_rate AS Adj_DX_2_SNF_rate_CLAIMS
   ,o.Adj_DX_2_SNF_rate AS Adj_DX_2_SNF_rate_OPS
   ,c.Adj_DX_3_SNF_rate AS Adj_DX_3_SNF_rate_CLAIMS
   ,o.Adj_DX_3_SNF_rate AS Adj_DX_3_SNF_rate_OPS
   ,c.dx1_counts AS dx1_counts_CLAIMS
   ,o.dx1_counts AS dx1_counts_OPS
   ,c.dx2_counts AS dx2_counts_CLAIMS
   ,o.dx2_counts AS dx2_counts_OPS
   ,c.dx3_counts AS dx3_counts_CLAIMS
   ,o.dx3_counts AS dx3_counts_OPS
FROM ( select * FROM DATALAB_WORK_PRD.DX_RISKS WHERE DATA_SOURCE='CLAIM' ) c 
 FULL OUTER JOIN (
 select * FROM DATALAB_WORK_PRD.DX_RISKS WHERE DATA_SOURCE='OPERATIONAL') o 
 USING (CLIENT,DX);
 
--REGION MOVED TO VIEW IN DAILY RUN (TO AVOID NULL DATA FOR NEW MEMBERS)
--patient hist table
--DROP TABLE IF EXISTS DATALAB_WORK_PRD.PATIENT_HISTORICAL_AND_DILIGENCE_WIDE_DEV; 
--CREATE TABLE DATALAB_WORK_PRD.PATIENT_HISTORICAL_AND_DILIGENCE_WIDE_DEV AS 
--SELECT
--  COALESCE(c.CLIENT,o.CLIENT) AS CLIENT, COALESCE(c.MEMBER_ID,o.MEMBER_ID) AS MEMBER_ID
--
--,COALESCE(c.STAY_ADMIT_DATE,o.STAY_ADMIT_DATE) AS STAY_ADMIT_DATE
--
--   ,COALESCE(c.FIRST_ADMIT_DATE,o.FIRST_ADMIT_DATE) AS FIRST_ADMIT_DATE
--   ,COALESCE(c.MEMBER_DAYS,o.MEMBER_DAYS) AS MEMBER_DAYS
--   ,COALESCE(c.MEMBER_DAYS_AddOne,o.MEMBER_DAYS_AddOne) AS MEMBER_DAYS_AddOne
--   ,COALESCE(c.yr_prior,o.yr_prior) AS yr_prior
--   ,COALESCE(c.sixMonth_prior,o.sixMonth_prior) AS sixMonth_prior
--   ,COALESCE(c.TWOyr_prior,o.TWOyr_prior) AS TWOyr_prior
--   ,COALESCE(c.MEMBER_MONTHS,o.MEMBER_MONTHS) AS MEMBER_MONTHS
--   ,COALESCE(c.MEMBER_MONTHS_AddOne,o.MEMBER_MONTHS_AddOne) AS MEMBER_MONTHS_AddOne
--   --,COALESCE(c.flu_flag,o.flu_flag) AS flu_flag
--   --,COALESCE(c.awv_flag,o.awv_flag) AS awv_flag
--   --,COALESCE(c.Office_Visit_Frequency,o.Office_Visit_Frequency) AS Office_Visit_Frequency
--   ,COALESCE(c.flu_counts,o.flu_counts) AS flu_counts
--   ,COALESCE(c.awv_counts,o.awv_counts) AS awv_counts
--   ,COALESCE(c.Office_Visit_Counts,o.Office_Visit_Counts) AS Office_Visit_Counts
--   ,COALESCE(c.flu_byMemMonths,o.flu_byMemMonths) AS flu_byMemMonths
--   ,COALESCE(c.awv_byMemMonths,o.awv_byMemMonths) AS awv_byMemMonths
--   ,COALESCE(c.ofv_byMemMonths,o.ofv_byMemMonths) AS ofv_byMemMonths
--   ,COALESCE(c.flu_byMemDays,o.flu_byMemDays) AS flu_byMemDays
--   ,COALESCE(c.awv_byMemDays,o.awv_byMemDays) AS awv_byMemDays
--   ,COALESCE(c.ofv_byMemDays,o.ofv_byMemDays) AS ofv_byMemDays
--   ,COALESCE(c.flu_counts_recent,o.flu_counts_recent) AS flu_counts_recent
--   ,COALESCE(c.awv_counts_recent,o.awv_counts_recent) AS awv_counts_recent
--   ,COALESCE(c.Office_Visit_Counts_recent,o.Office_Visit_Counts_recent) AS Office_Visit_Counts_recent
--   ,COALESCE(c.flu_byMemMonths_recent,o.flu_byMemMonths_recent) AS flu_byMemMonths_recent
--   ,COALESCE(c.awv_byMemMonths_recent,o.awv_byMemMonths_recent) AS awv_byMemMonths_recent
--   ,COALESCE(c.ofv_byMemMonths_recent,o.ofv_byMemMonths_recent) AS ofv_byMemMonths_recent
--   ,COALESCE(c.flu_byMemDays_recent,o.flu_byMemDays_recent) AS flu_byMemDays_recent
--   ,COALESCE(c.awv_byMemDays_recent,o.awv_byMemDays_recent) AS awv_byMemDays_recent
--   ,COALESCE(c.ofv_byMemDays_recent,o.ofv_byMemDays_recent) AS ofv_byMemDays_recent
--   ,c.total_admit_count AS total_admit_count_CLAIMS
--   ,o.total_admit_count AS total_admit_count_OPS
--   ,c.total_admit_count_byMemMonths AS total_admit_count_byMemMonths_CLAIMS
--   ,o.total_admit_count_byMemMonths AS total_admit_count_byMemMonths_OPS
--   ,c.total_admit_count_byMemDays AS total_admit_count_byMemDays_CLAIMS
--   ,o.total_admit_count_byMemDays AS total_admit_count_byMemDays_OPS
--   ,c.hist_readmit_90_rate_byMemMonths AS hist_readmit_90_rate_byMemMonths_CLAIMS
--   ,o.hist_readmit_90_rate_byMemMonths AS hist_readmit_90_rate_byMemMonths_OPS
--   ,c.hist_readmit_90_rate_byMemDays AS hist_readmit_90_rate_byMemDays_CLAIMS
--   ,o.hist_readmit_90_rate_byMemDays AS hist_readmit_90_rate_byMemDays_OPS
--   --,c.Streak_flag AS Streak_flag_CLAIMS
--   --,o.Streak_flag AS Streak_flag_OPS
--   --,c.grouping_noReadmitsMAX AS grouping_noReadmitsMAX_CLAIMS
--   --,o.grouping_noReadmitsMAX AS grouping_noReadmitsMAX_OPS
--   ,c.Streak_90 AS Streak_90_CLAIMS
--   ,o.Streak_90 AS Streak_90_OPS
--   ,c.No_Streak AS No_Streak_CLAIMS
--   ,o.No_Streak AS No_Streak_OPS
--   ,c.Count_180 AS Count_180_CLAIMS
--   ,o.Count_180 AS Count_180_OPS
--   ,c.Count_180_byMemMonths AS Count_180_byMemMonths_CLAIMS
--   ,o.Count_180_byMemMonths AS Count_180_byMemMonths_OPS
--   ,c.Count_180_byMemDays AS Count_180_byMemDays_CLAIMS
--   ,o.Count_180_byMemDays AS Count_180_byMemDays_OPS
--   ,c.Count_365 AS Count_365_CLAIMS
--   ,o.Count_365 AS Count_365_OPS
--   ,c.Count_365_byMemMonths AS Count_365_byMemMonths_CLAIMS
--   ,o.Count_365_byMemMonths AS Count_365_byMemMonths_OPS
--   ,c.Count_365_byMemDays AS Count_365_byMemDays_CLAIMS
--   ,o.Count_365_byMemDays AS Count_365_byMemDays_OPS
--   ,c.snf_hist AS snf_hist_CLAIMS
--   ,o.snf_hist AS snf_hist_OPS
--   ,c.Historical_DX1_readmission_risk AS Historical_DX1_readmission_risk_CLAIMS
--   ,o.Historical_DX1_readmission_risk AS Historical_DX1_readmission_risk_OPS
--   ,c.Historical_DX2_readmission_risk AS Historical_DX2_readmission_risk_CLAIMS
--   ,o.Historical_DX2_readmission_risk AS Historical_DX2_readmission_risk_OPS
--   ,c.Historical_DX3_readmission_risk AS Historical_DX3_readmission_risk_CLAIMS
--   ,o.Historical_DX3_readmission_risk AS Historical_DX3_readmission_risk_OPS
--   ,c.MAX_Adj_DX_1_RR AS MAX_Adj_DX_1_RR_CLAIMS
--   ,o.MAX_Adj_DX_1_RR AS MAX_Adj_DX_1_RR_OPS
--   ,c.MAX_Adj_DX_2_RR AS MAX_Adj_DX_2_RR_CLAIMS
--   ,o.MAX_Adj_DX_2_RR AS MAX_Adj_DX_2_RR_OPS
--   ,c.MAX_Adj_DX_3_RR AS MAX_Adj_DX_3_RR_CLAIMS
--   ,o.MAX_Adj_DX_3_RR AS MAX_Adj_DX_3_RR_OPS
--   ,c.Historical_DX1_SNF_risk AS Historical_DX1_SNF_risk_CLAIMS
--   ,o.Historical_DX1_SNF_risk AS Historical_DX1_SNF_risk_OPS
--   ,c.Historical_DX2_SNF_risk AS Historical_DX2_SNF_risk_CLAIMS
--   ,o.Historical_DX2_SNF_risk AS Historical_DX2_SNF_risk_OPS
--   ,c.Historical_DX3_SNF_risk AS Historical_DX3_SNF_risk_CLAIMS
--   ,o.Historical_DX3_SNF_risk AS Historical_DX3_SNF_risk_OPS
--   ,c.MAX_Adj_DX_1_SNF_rate AS MAX_Adj_DX_1_SNF_rate_CLAIMS
--   ,o.MAX_Adj_DX_1_SNF_rate AS MAX_Adj_DX_1_SNF_rate_OPS
--   ,c.MAX_Adj_DX_2_SNF_rate AS MAX_Adj_DX_2_SNF_rate_CLAIMS
--   ,o.MAX_Adj_DX_2_SNF_rate AS MAX_Adj_DX_2_SNF_rate_OPS
--   ,c.MAX_Adj_DX_3_SNF_rate AS MAX_Adj_DX_3_SNF_rate_CLAIMS
--   ,o.MAX_Adj_DX_3_SNF_rate AS MAX_Adj_DX_3_SNF_rate_OPS
--   ,c.MAX_hist_MicrocardialInfarction AS MAX_hist_MicrocardialInfarction_CLAIMS
--   ,o.MAX_hist_MicrocardialInfarction AS MAX_hist_MicrocardialInfarction_OPS
--   ,c.MAX_hist_CHF AS MAX_hist_CHF_CLAIMS
--   ,o.MAX_hist_CHF AS MAX_hist_CHF_OPS
--   ,c.MAX_hist_PeripheralVascular AS MAX_hist_PeripheralVascular_CLAIMS
--   ,o.MAX_hist_PeripheralVascular AS MAX_hist_PeripheralVascular_OPS
--   ,c.MAX_hist_Cerebrovascular AS MAX_hist_Cerebrovascular_CLAIMS
--   ,o.MAX_hist_Cerebrovascular AS MAX_hist_Cerebrovascular_OPS
--   ,c.MAX_hist_Dementia AS MAX_hist_Dementia_CLAIMS
--   ,o.MAX_hist_Dementia AS MAX_hist_Dementia_OPS
--   ,c.MAX_hist_Pulmonary AS MAX_hist_Pulmonary_CLAIMS
--   ,o.MAX_hist_Pulmonary AS MAX_hist_Pulmonary_OPS
--   ,c.MAX_hist_Rheumatic AS MAX_hist_Rheumatic_CLAIMS
--   ,o.MAX_hist_Rheumatic AS MAX_hist_Rheumatic_OPS
--   ,c.MAX_hist_PepticUlcer AS MAX_hist_PepticUlcer_CLAIMS
--   ,o.MAX_hist_PepticUlcer AS MAX_hist_PepticUlcer_OPS
--   ,c.MAX_hist_MildLiver AS MAX_hist_MildLiver_CLAIMS
--   ,o.MAX_hist_MildLiver AS MAX_hist_MildLiver_OPS
--   ,c.MAX_hist_DiabetesWithout AS MAX_hist_DiabetesWithout_CLAIMS
--   ,o.MAX_hist_DiabetesWithout AS MAX_hist_DiabetesWithout_OPS
--   ,c.MAX_hist_DiabetesWith AS MAX_hist_DiabetesWith_CLAIMS
--   ,o.MAX_hist_DiabetesWith AS MAX_hist_DiabetesWith_OPS
--   ,c.MAX_hist_Hemiplegia AS MAX_hist_Hemiplegia_CLAIMS
--   ,o.MAX_hist_Hemiplegia AS MAX_hist_Hemiplegia_OPS
--   ,c.MAX_hist_Renal AS MAX_hist_Renal_CLAIMS
--   ,o.MAX_hist_Renal AS MAX_hist_Renal_OPS
--   ,c.MAX_hist_Malignancy AS MAX_hist_Malignancy_CLAIMS
--   ,o.MAX_hist_Malignancy AS MAX_hist_Malignancy_OPS
--   ,c.MAX_hist_Liver AS MAX_hist_Liver_CLAIMS
--   ,o.MAX_hist_Liver AS MAX_hist_Liver_OPS
--   ,c.MAX_hist_Metastatic AS MAX_hist_Metastatic_CLAIMS
--   ,o.MAX_hist_Metastatic AS MAX_hist_Metastatic_OPS
--   ,c.MAX_hist_AIDSHIV AS MAX_hist_AIDSHIV_CLAIMS
--   ,o.MAX_hist_AIDSHIV AS MAX_hist_AIDSHIV_OPS
--   ,c.CharlsonComorbidityIndex AS CharlsonComorbidityIndex_CLAIMS
--   ,o.CharlsonComorbidityIndex AS CharlsonComorbidityIndex_OPS
--FROM ( select * FROM DATALAB_WORK_PRD.PATIENT_HISTORICAL_AND_DILIGENCE_DEV WHERE DATA_SOURCE='CLAIM' ) c 
-- FULL OUTER JOIN (
-- select * FROM DATALAB_WORK_PRD.PATIENT_HISTORICAL_AND_DILIGENCE_DEV WHERE DATA_SOURCE='OPERATIONAL') o 
-- USING (CLIENT,MEMBER_ID,STAY_ADMIT_DATE);
--END REGION
--end region

--SELECT * FROM DATALAB_WORK_PRD.PATIENT_HISTORICAL_AND_DILIGENCE_WIDE_DEV
----WHERE MEMBER_ID='0035916109'AND CLIENT = 'WELLCARE' --streak_90 > 2 LIMIT 100
--WHERE CLIENT = 'AMBETTER' AND MEMBER_ID='U9517014101'
--order bY STAY_ADMIT_dATE
--;


--region explore when multiple first admit date

----see total counts
--SELECT COUNT(*) FROM DATALAB_WORK_PRD.PATIENT_HISTORICAL_AND_DILIGENCE_DEV;
----find a client and see summary stats for this
--
--
--SELECT CLIENT,COUNT(*), COUNT(*)/1787996*100 AS ratio
--FROM (
--SELECT CLIENT,MEMBER_ID, COUNT(DISTINCT FIRST_ADMIT_DATE)
--FROM DATALAB_WORK_PRD.PATIENT_HISTORICAL_AND_DILIGENCE_DEV
--GROUP BY 1,2
--HAVING COUNT(DISTINCT FIRST_ADMIT_DATE) >1
----LIMIT 100
--) foo
--GROUP BY 1
----LIMIT 100
--;
----look at 1 client
--SELECT * 
--FROM DATALAB_WORK_PRD.PATIENT_HISTORICAL_AND_DILIGENCE_DEV
--WHERE CLIENT = 'WELLCARE' AND member_id='070054078'
--;
--
--SELECT * 
--FROM DATALAB_WORK_PRD.PATIENT_HISTORICAL_AND_DILIGENCE_WIDE_DEV
--WHERE CLIENT = 'WELLCARE' AND member_id='070054078'
--;

--end region

