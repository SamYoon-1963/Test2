--explore if need to use pos 21 as filter here... b/c may want to use this for outside pos 21 joins later on..
--not sure b/c only 644 npis have more than 1 pos
--high count npis pretty similar readmit rates
--low count npis will be mean adjusted

--SELECT FACILITY_NPI, COUNT(*) AS COUNTS, COUNT(DISTINCT POS) AS D_POS, 
--AVG(EPI_HAS_READMIT_90_DAY) AS avg_all_readmit, 
--AVG(CASE WHEN POS ='21' THEN EPI_HAS_READMIT_90_DAY ELSE NULL END) AS avg_hos_readmit_null,
--AVG(CASE WHEN POS ='21' THEN EPI_HAS_READMIT_90_DAY END) AS avg_hos_readmit,
--SUM(CASE WHEN POS ='21' THEN EPI_HAS_READMIT_90_DAY END)/NULLIFZERO(SUM(CASE WHEN POS='21' THEN 1 ELSE 0 END)) AS sumCnt_hos_readmit,
--SUM(CASE WHEN POS ='21' THEN EPI_HAS_READMIT_90_DAY ELSE NULL END)/NULLIFZERO(SUM(CASE WHEN POS='21' THEN 1 ELSE 0 END)) AS sumCnt_hos_readmit_null
--from MEDECON_PRD.PDM
--WHERE STAY_DISCHARGE_DATE <= ADD_MONTHS(PAID_THRU_DATE,-5)
--GROUP BY 1
--HAVING COUNT(DISTINCT POS) >1
--ORDER BY COUNTS
--;

--QUESTION: UPDATE ENSURE THESE ARE UNIQUE NPI NOT COMMON_NPI?
--region code for mu (population mean)
DROP TABLE IF EXISTS overall_rr;
CREATE LOCAL TEMP TABLE overall_rr ON COMMIT PRESERVE ROWS AS
SELECT 
	DATA_SOURCE,
  POS,
  --ADD_MONTHS(PAID_THRU_DATE,-5) AS WINDOW_LIMIT,
	sum(EPI_HAS_READMIT_90_DAY) AS count_readmit_90,
	COUNT(*) AS counts,
	sum(EPI_HAS_READMIT_90_DAY)/COUNT(*) AS readmit_rate --THIS WILL BE the MU for pop readmit rate
FROM MEDECON_PRD.PDM p
--USE discharge date DATA 5 MONTHS PRIOR TO PAIDTHRU DATE FOR RUN OUT FOR INR
WHERE  p.STAY_DISCHARGE_DATE <= ADD_MONTHS(PAID_THRU_DATE,-5)--w.WINDOW_LIMIT
GROUP BY 1,2
;
SELECT * FROM overall_rr LIMIT 100;
--end region

DROP TABLE IF EXISTS DATALAB_WORK_PRD.NPI_RISKS_DEV;
CREATE TABLE DATALAB_WORK_PRD.NPI_RISKS_DEV AS
select 
a.DATA_SOURCE,
--CLIENT,
a.POS,
a.Facility_NPI as NPI,
b.readmit_rate AS data_source_rr_rate,
(sum(EPI_HAS_READMIT_90_DAY)+b.readmit_rate)/(count(*)+1) as Adj_NPI_risk
,sum(EPI_HAS_READMIT_90_DAY)/(count(*)+1) as NPI_risk
,count(*) AS npi_counts
from MEDECON_PRD.PDM a
LEFT JOIN overall_rr b
ON a.DATA_SOURCE= b.DATA_SOURCE AND a.POS=b.POS
where
--LEAVE RUN OUT, only take data discharge days 90 days prior to paid_thru_date
a.STAY_DISCHARGE_DATE <= ADD_MONTHS(PAID_THRU_DATE,-5)
GROUP BY 1,2,3,4
;


