--THIS CODE CALCULATEs THE ADJUSTED READMISSION RISK SCORE BY DX CODE BY CLIENT AND DATA SOURCE

--NOTES:
--NEED To BE CONSISSTENT FILTERS WITH TRAINING DATA
--IS HARD CODED AND PREDICTIONS ARE MADE ON IT, UNTIL RETRAINING UPDATES THE TABLE



--region code for mu (population mean)
DROP TABLE IF EXISTS client_rr;
CREATE LOCAL TEMP TABLE client_rr ON COMMIT PRESERVE ROWS AS
SELECT 
	DATA_SOURCE,
  CLIENT,
  ADD_MONTHS(PAID_THRU_DATE,-5) AS WINDOW_LIMIT,
	sum(EPI_HAS_READMIT_90_DAY) AS count_readmit_90,
	COUNT(*) AS client_count,
	sum(EPI_HAS_READMIT_90_DAY)/COUNT(*) AS client_readmit_rate, --THIS WILL BE the MU for pop readmit rate
  sum(case when NEXT_POS = '31' and (NEXT_STAY_ADMIT_DATE-1) - STAY_DISCHARGE_DATE <= 3 then 1 else 0 end)/COUNT(*) AS client_snf_rate  --THIS WILL BE the MU for pop snf rate rate
FROM MEDECON_PRD.PDM p
--LEFT JOIN client_PT_DATE w
--ON p.CLIENT=w.CLIENT AND p.DATA_SOURCE=w.DATA_SOURCE
WHERE POS = '21'
--USE discharge date DATA 3 MONTHS (90 DAYS) PRIOR TO PAIDTHRU DATE FOR RUN OUT
AND p.STAY_DISCHARGE_DATE <= ADD_MONTHS(PAID_THRU_DATE,-5)--w.WINDOW_LIMIT
--AND p.NEXT_POS = '31' and (p.NEXT_STAY_ADMIT_DATE-1) - p.STAY_DISCHARGE_DATE <= 3 
GROUP BY 1,2,3
;
--end region

--SELECT * FROM client_rr ORDER BY CLIENT, WINDOW_LIMIT DESC;

--REGION CREATE DIAGNOSIS 1 RISK ADJUSTED SCORE (by client)
DROP TABLE IF EXISTS dx1_rr;
CREATE LOCAL TEMP TABLE dx1_rr ON COMMIT PRESERVE ROWS AS
  select 
  a.DATA_SOURCE,
  a.CLIENT,
  a.DX1 as DX,
  b.client_readmit_rate,
  b.client_snf_rate,
  (sum(EPI_HAS_READMIT_90_DAY)+b.client_readmit_rate)/(count(a.DX1)+1) as Adj_DX_1_RR  --UPDATE: using dynamic client readmit rate as population mu
  ,(sum(case when a.NEXT_POS = '31' and (a.NEXT_STAY_ADMIT_DATE-1) - a.STAY_DISCHARGE_DATE <= 3 then 1 else 0 end) +b.client_snf_rate)/(count(a.DX1)+1) as Adj_DX_1_SNF_rate
     --how many times is this dx code present for the data source and client
   ,COUNT(*) AS dx1_counts
from MEDECON_PRD.PDM a
LEFT JOIN client_rr b
ON a.CLIENT = b.CLIENT AND a.DATA_SOURCE= b.DATA_SOURCE
where
a.POS = '21' AND --Inpatient stays only
--LEAVE RUN OUT, only take data discharge days 90 days prior to paid_thru_date
a.STAY_DISCHARGE_DATE <= b.WINDOW_LIMIT
group by 1,2,3,4,5
;
--END REGION

--SELECT * FROM dx1_rr LIMIT 100;

--REGION CREATE DIAGNOSIS 2 RISK ADJUSTED SCORE (by client)
  DROP TABLE IF EXISTS dx2_rr;
CREATE LOCAL TEMP TABLE dx2_rr ON COMMIT PRESERVE ROWS AS
  select 
  a.DATA_SOURCE,
  a.CLIENT,
  a.DX2 as DX,
  b.client_readmit_rate,
  b.client_snf_rate,
  (sum(EPI_HAS_READMIT_90_DAY)+b.client_readmit_rate)/(count(a.DX2)+1) as Adj_DX_2_RR  --UPDATE: using dynamic client readmit rate as population mu
  ,(sum(case when a.NEXT_POS = '31' and (a.NEXT_STAY_ADMIT_DATE-1) - a.STAY_DISCHARGE_DATE <= 3 then 1 else 0 end) +b.client_snf_rate)/(count(a.DX2)+1) as Adj_DX_2_SNF_rate
     --how many times is this dx code present for the data source and client
   ,COUNT(*) AS dx2_counts
from MEDECON_PRD.PDM a
LEFT JOIN client_rr b
ON a.CLIENT = b.CLIENT AND a.DATA_SOURCE= b.DATA_SOURCE
where
a.POS = '21' AND --Inpatient stays only
--LEAVE RUN OUT, only take data discharge days 90 days prior to paid_thru_date
a.STAY_DISCHARGE_DATE <= b.WINDOW_LIMIT
group by 1,2,3,4,5
;
--END REGION

--SELECT * FROM dx2_rr  ORDER BY DX  LIMIT 100;

--REGION CREATE DIAGNOSIS 3 RISK ADJUSTED SCORE (by client)
  DROP TABLE IF EXISTS dx3_rr;
CREATE LOCAL TEMP TABLE dx3_rr ON COMMIT PRESERVE ROWS AS
  select 
  a.DATA_SOURCE,
  a.CLIENT,
  a.DX3 as DX,
  b.client_readmit_rate,
    b.client_snf_rate,
  (sum(EPI_HAS_READMIT_90_DAY)+b.client_readmit_rate)/(count(a.DX3)+1) as Adj_DX_3_RR  --UPDATE: using dynamic client readmit rate as population mu
   ,(sum(case when a.NEXT_POS = '31' and (a.NEXT_STAY_ADMIT_DATE-1) - a.STAY_DISCHARGE_DATE <= 3 then 1 else 0 end) +b.client_snf_rate)/(count(a.DX3)+1) as Adj_DX_3_SNF_rate
   --how many times is this dx code present for the data source and client
   ,COUNT(*) AS dx3_counts
from MEDECON_PRD.PDM a
LEFT JOIN client_rr b
ON a.CLIENT = b.CLIENT AND a.DATA_SOURCE= b.DATA_SOURCE
where
a.POS = '21' AND --Inpatient stays only
--LEAVE RUN OUT, only take data discharge days 90 days prior to paid_thru_date
a.STAY_DISCHARGE_DATE <= b.WINDOW_LIMIT
group by 1,2,3,4,5
;
--END REGION

--SELECT * FROM dx3_rr LIMIT 100;

--region create final static  table
--create table of all dx codes by data source and client
DROP TABLE IF EXISTS all_dx;
CREATE LOCAL TEMP TABLE all_dx ON COMMIT PRESERVE ROWS AS
SELECT DATA_SOURCE, CLIENT, DX FROM dx1_rr
UNION 
SELECT DATA_SOURCE, CLIENT, DX FROM dx2_rr
UNION 
SELECT DATA_SOURCE, CLIENT, DX FROM dx3_rr
;
--SELECT * FROM all_dx LIMIT 100;


--create static table with 3 risk scores for each dx code
--risk score dependent if seen as dx 1, 2 or 3
--split by data source and client
DROP TABLE IF EXISTS DATALAB_WORK_PRD.DX_RISKS;
CREATE TABLE DATALAB_WORK_PRD.DX_RISKS AS --create static table
SELECT a.DATA_SOURCE, a.CLIENT, a.DX,
b.Adj_DX_1_RR,
c.Adj_DX_2_RR, 
d.Adj_DX_3_RR,
b.Adj_DX_1_SNF_rate,
c.Adj_DX_2_SNF_rate, 
d.Adj_DX_3_SNF_rate,
b.dx1_counts,
c.dx2_counts,
d.dx3_counts
FROM  all_dx a
LEFT JOIN dx1_rr b ON a.DATA_SOURCE = b.DATA_SOURCE AND a.CLIENT =b.CLIENT AND a.DX= b.DX
LEFT JOIN dx2_rr c ON a.DATA_SOURCE = c.DATA_SOURCE AND a.CLIENT =c.CLIENT AND a.DX= c.DX
LEFT JOIN dx3_rr d ON a.DATA_SOURCE = d.DATA_SOURCE AND a.CLIENT =d.CLIENT AND a.DX= d.DX
;
--end region


--SELECT * FROM DATALAB_WORK_PRD.DX_RISKS 
--ORDER BY DX3_counts DESC
--LIMIT 100;
